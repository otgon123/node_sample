// express module
const express = require('express')
// router object sakusei
const router = express.Router()

//module
module.exports = router